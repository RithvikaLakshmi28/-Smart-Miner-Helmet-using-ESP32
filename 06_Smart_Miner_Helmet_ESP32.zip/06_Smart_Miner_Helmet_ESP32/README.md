# Smart Miner Helmet using ESP32

An educational mine-safety monitoring prototype using ESP32 and environmental sensors to detect hazardous conditions and generate local alerts.

## Monitored parameters
- Gas concentration
- Temperature and humidity
- Ambient light
- Vibration/shock events

## Features
- ESP32 sensor acquisition
- Threshold-based local alerts
- Buzzer and status LEDs
- Optional OLED/LCD
- Optional Wi-Fi dashboard or cloud telemetry

## Files
- `src/smart_miner_helmet.ino`
- `docs/pinout.md`
- `docs/working_principle.md`
- `block_diagram.png`

> This is an educational prototype, not a certified mine-safety device. Gas thresholds must be calibrated using the exact sensor and application requirements.
