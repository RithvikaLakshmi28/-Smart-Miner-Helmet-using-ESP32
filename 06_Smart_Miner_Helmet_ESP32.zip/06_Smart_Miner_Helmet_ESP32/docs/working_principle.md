# Working Principle

1. Gas, light, vibration, temperature, and humidity sensors monitor the environment.
2. ESP32 periodically samples the sensor values.
3. Sensor readings are compared with configured prototype thresholds.
4. A hazardous condition activates the buzzer and red LED.
5. Normal conditions keep the green status indicator active.
6. Wi-Fi can be added to transmit sensor data and alerts to a dashboard.
