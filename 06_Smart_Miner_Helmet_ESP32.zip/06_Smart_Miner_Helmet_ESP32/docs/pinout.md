# Suggested Pinout

| Sensor/Output | ESP32 |
|---|---:|
| Gas sensor analog | GPIO34 |
| LDR analog | GPIO35 |
| Vibration sensor | GPIO27 |
| Buzzer | GPIO25 |
| Red LED | GPIO26 |
| Green LED | GPIO2 |
| OLED SDA | GPIO21 |
| OLED SCL | GPIO22 |

If using DHT11/DHT22, connect it to a suitable GPIO and add the corresponding DHT library and sensor-specific code.
