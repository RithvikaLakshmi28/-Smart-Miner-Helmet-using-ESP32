/*
  Smart Miner Helmet using ESP32
  Educational safety-monitoring prototype.
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define GAS_PIN       34
#define VIBRATION_PIN 27
#define LDR_PIN       35
#define BUZZER_PIN    25
#define RED_LED       26
#define GREEN_LED     2

#define TEMP_HUMIDITY_SDA 21
#define TEMP_HUMIDITY_SCL 22

const int GAS_THRESHOLD = 2200;
const int LIGHT_THRESHOLD = 1000;

Adafruit_SSD1306 display(128, 64, &Wire, -1);

void alertOn()
{
  digitalWrite(RED_LED, HIGH);
  digitalWrite(GREEN_LED, LOW);
  tone(BUZZER_PIN, 1800);
}

void alertOff()
{
  noTone(BUZZER_PIN);
  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);
}

void setup()
{
  Serial.begin(115200);

  pinMode(VIBRATION_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);

  Wire.begin(TEMP_HUMIDITY_SDA, TEMP_HUMIDITY_SCL);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("SMART MINER HELMET");
  display.println("System Ready");
  display.display();

  alertOff();
}

void loop()
{
  int gasValue = analogRead(GAS_PIN);
  int lightValue = analogRead(LDR_PIN);
  int vibration = digitalRead(VIBRATION_PIN);

  bool danger = gasValue > GAS_THRESHOLD || vibration == HIGH;

  if (danger)
    alertOn();
  else
    alertOff();

  Serial.print("Gas: ");
  Serial.print(gasValue);
  Serial.print(" | Light: ");
  Serial.print(lightValue);
  Serial.print(" | Vibration: ");
  Serial.println(vibration);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("MINER HELMET");
  display.print("Gas: "); display.println(gasValue);
  display.print("Light: "); display.println(lightValue);
  display.print("Vibration: "); display.println(vibration);
  display.print("Status: ");
  display.println(danger ? "ALERT" : "SAFE");
  display.display();

  delay(500);
}
